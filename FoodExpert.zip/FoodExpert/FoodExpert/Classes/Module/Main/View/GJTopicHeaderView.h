//
//  GJTopicHeaderView.h
//  FoodExpert
//
//  Created by qf on 16/04/07.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJTopicHeaderView : UITableViewHeaderFooterView

/**
 *  返回自定制的专题组头视图
 *
 *  @param tableView 显示的表格视图
 */
+ (instancetype)sectionViewWithTableView:(UITableView *)tableView;

/**
 *  查看更多专题block
 */
@property (nonatomic, copy) void(^ShowMoreTopicAction)();

@end
