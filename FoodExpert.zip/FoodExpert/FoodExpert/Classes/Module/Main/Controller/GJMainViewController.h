//
//  GJMainViewController.h
//  FoodExpert
//
//  Created by qf on 16/04/07.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJMainViewController : UIViewController

@property (nonatomic, copy) void(^OpenLeftMenuViewAction)(BOOL isOpen);

@property (nonatomic, strong) UIView * coverView;

@end
