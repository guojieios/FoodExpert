//
//  GJMoreTopicController.h
//  FoodExpert
//
//  Created by ljunb on 16/04/07.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJBaseViewController.h"

@interface GJMoreTopicController : GJBaseViewController

/**
 *  更多专题数组
 */
@property (nonatomic, strong) NSArray * moreTopics;

@end
