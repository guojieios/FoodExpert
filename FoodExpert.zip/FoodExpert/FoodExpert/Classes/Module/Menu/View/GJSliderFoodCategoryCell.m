//
//  GJSliderMenuSectionView.m
//  FoodExpert
//
//  Created by qf on 16/04/09.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJSliderFoodCategoryCell.h"

@interface GJSliderFoodCategoryCell ()
/**
 *  食物分类标题
 */
@property (nonatomic, strong) UILabel * title;

@end

@implementation GJSliderFoodCategoryCell

#pragma mark - 工厂方法
+ (instancetype)cellWithTableView:(UITableView *)tableView {
    
    static NSString * ID = @"slider_food_category_cell";
    
    GJSliderFoodCategoryCell * cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (!cell) {
        cell = [[GJSliderFoodCategoryCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor = [UIColor clearColor];
    return cell;
}

#pragma mark - 重写初始化方法
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self addSubviews];
    }
    return self;
}

#pragma mark - 适配子控件
- (void)addSubviews {
    
    [self.title mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left).offset(15);
        make.bottom.equalTo(self.contentView.mas_bottom).offset(-10);
        make.height.equalTo(@15);
    }];
    self.title.text = @"食物分类";
}

#pragma mark - getter
- (UILabel *)title {
    
    if (!_title) {
        _title = [[UILabel alloc] init];
        _title.font = [UIFont systemFontOfSize:13];
        _title.textColor = [UIColor whiteColor];
        [self.contentView addSubview:_title];
    }
    return _title;
}

@end
