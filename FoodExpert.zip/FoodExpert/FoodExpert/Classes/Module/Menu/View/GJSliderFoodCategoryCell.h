//
//  GJSliderMenuSectionView.h
//  FoodExpert
//
//  Created by qf on 16/04/09.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJSliderFoodCategoryCell : UITableViewCell

/**
 *  快速创建侧滑菜单cell
 *
 *  @param tableView 装载的tableView
 *
 *  @return 返回自定义的侧滑菜单cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;



@end
