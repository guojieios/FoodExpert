//
//  GJSliderMenuViewController.h
//  FoodExpert
//
//  Created by qf on 16/04/09.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJSliderMenuViewController : UIViewController

@end
