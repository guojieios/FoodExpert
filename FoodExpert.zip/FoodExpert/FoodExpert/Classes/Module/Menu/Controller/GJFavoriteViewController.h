//
//  GJFavoriteViewController.h
//  FoodExpert
//
//  Created by qf on 16/04/09.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJBaseViewController.h"

@interface GJFavoriteViewController : GJBaseViewController

@end
