//
//  LJBTopicViewController.h
//  FoodExpert
//
//  Created by qf on 16/04/18.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJTopicViewController : UICollectionViewController

/**
 *  请求专题的id
 */
@property (nonatomic, copy) NSString * topic_id;

@end
