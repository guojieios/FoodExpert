//
//  LJBTopicPage.m
//  FoodExpert
//
//  Created by qf on 16/04/18.
//  Copyright © 2016年 qf. All rights reserved.
//  专题详情页


#import "GJTopicPage.h"

@implementation GJTopicPage

+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"Description":@"description"};
}

@end
