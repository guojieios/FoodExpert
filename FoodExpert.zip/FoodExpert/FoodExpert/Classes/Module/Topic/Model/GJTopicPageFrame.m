//
//  LJBTopicPageFrame.m
//  FoodExpert
//
//  Created by qf on 16/04/18.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJTopicPageFrame.h"
#import "GJTopicPage.h"

@implementation GJTopicPageFrame

- (void)setModel:(GJTopicPage *)model {
    
    _model = model;
    
    _contentHeight = [model.Description boundingRectWithSize:CGSizeMake(KScreenSize.width-10*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size.height + KScreenSize.height*0.4 + 110;
}

@end
