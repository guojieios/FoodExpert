//
//  LJBTopicPageFrame.h
//  FoodExpert
//
//  Created by qf on 16/04/18.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>

@class GJTopicPage;

@interface GJTopicPageFrame : NSObject
/**
 *  专题美食模型
 */
@property (nonatomic, strong) GJTopicPage * model;

/**
 *  可滚动高度
 */
@property (nonatomic, assign) CGFloat contentHeight;


@end
