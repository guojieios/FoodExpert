//
//  LJBTopicIndicatiorView.h
//  FoodExpert
//
//  Created by qf on 16/04/18.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJTopicIndicatiorView : UIView

/**
 *  设置页码指示图
 *
 *  @param pageCount 页码数
 */
- (void)configViewWithPageCount:(NSInteger)pageCount;

/**
 *  更新页码
 *
 *  @param index 页码下标
 */
- (void)updatePageIndicatorWithIndex:(NSInteger)index;

@end
