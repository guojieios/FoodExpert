//
//  LJBTopicDetailCell.h
//  FoodExpert
//
//  Created by qf on 16/04/18.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJTopicPageFrame;

@interface GJTopicDetailCell : UICollectionViewCell

@property (nonatomic, copy) void(^ShowFoodDetailAction)();

- (void)configCellWithModel:(GJTopicPageFrame *)model;

@end
