//
//  GJFoodGroupSubCategory.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//  食物二级分类
/**
 *  "id": 13,
 "name": "包装谷薯",
 "image_url": null
 */

#import <Foundation/Foundation.h>

@interface GJFoodGroupSubCategory : NSObject <MJKeyValue>

@property (nonatomic, copy) NSString * ID;

@property (nonatomic, copy) NSString * name;

@property (nonatomic, copy) NSString * image_url;

@end
