//
//  GJFoodGroupSubCategory.m
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodGroupSubCategory.h"

@implementation GJFoodGroupSubCategory

+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}

@end
