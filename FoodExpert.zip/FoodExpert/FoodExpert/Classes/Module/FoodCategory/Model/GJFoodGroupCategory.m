//
//  GJFoodGroupCategory.m
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodGroupCategory.h"
#import "GJFoodGroupSubCategory.h"

@implementation GJFoodGroupCategory

+ (NSDictionary *)objectClassInArray {
    
    return @{@"sub_categories":[GJFoodGroupSubCategory class]};
}

+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"ID":@"id", @"Description":@"description"};
}

@end
