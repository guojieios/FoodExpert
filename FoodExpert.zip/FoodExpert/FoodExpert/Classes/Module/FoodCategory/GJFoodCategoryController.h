//
//  LJBBaseFoodCategoryController.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJBaseViewController.h"

@interface GJFoodCategoryController : GJBaseViewController

/**
 *  需要显示的模型数组
 */
@property (nonatomic, strong) NSMutableArray * items;

/**
 *  item类型
 */
@property (nonatomic, assign) KFoodCategoryItemType itemType;

/**
 *  分类
 */
@property (nonatomic, copy) NSString * category;

@end
