//
//  LJBFoodSeasonCell.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJFoodGroupCategory;

@interface GJFoodSeasonCell : UITableViewCell

/**
 *  工厂方法
 *
 *  @param tableView 装载的TableView
 *
 *  @return 自定义的季节cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;

/**
 *  食物分类模型
 */
@property (nonatomic, strong) GJFoodGroupCategory * categoryModel;

@end
