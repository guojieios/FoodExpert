//
//  LJBCategoryItemView.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJFoodGroupCategory;

@interface GJCategoryItemView : UIView

@property (nonatomic, strong) GJFoodGroupCategory * categoryModel;

@end
