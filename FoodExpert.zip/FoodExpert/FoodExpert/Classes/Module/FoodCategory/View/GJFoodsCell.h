//
//  GJFoodsCell.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJFood;

@interface GJFoodsCell : UITableViewCell

/**
 *  工厂方法
 *
 *  @param tableView 装载的TableView
 *
 *  @return 自定义的季节cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;

/**
 *  配置cell
 *
 *  @param foodModel  食物模型
 *  @param orderIndex 对应的排序类型
 */
- (void)configCellWithModel:(GJFood *)foodModel orderBy:(NSInteger)orderIndex;


@end
