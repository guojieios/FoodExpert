//
//  GJFoodSubViewController.m
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodSubViewController.h"

@interface GJFoodSubViewController ()

@end

@implementation GJFoodSubViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)backAction {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
