//
//  LJBFoodsDetailController.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJBaseViewController.h"

@class GJFoodGroupCategory;

@interface GJFoodsDetailController : GJBaseViewController

/**
 *  食物种类
 */
@property (nonatomic, copy) NSString * kind;

/**
 *  食物模型
 */
@property (nonatomic, strong) GJFoodGroupCategory * model;


@end
