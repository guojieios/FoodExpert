//
//  GJFoodCategotySeasonController.m
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodCategotySeasonController.h"
#import "GJFoodNetworker.h"
#import "UIImageView+WebCache.h"
#import "GJFoodGroupCategory.h"
#import "GJFoodSeasonCell.h"
#import "GJFoodsDetailController.h"

@interface GJFoodCategotySeasonController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView * tableView;

@property (nonatomic, strong) NSMutableArray * seasons;

@end

@implementation GJFoodCategotySeasonController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self getDataFromServer];
}

#pragma mark - 返回按钮
- (void)backAction {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 请求数据
- (void)getDataFromServer {
    
    [GJFoodNetworker getFoodCategoryDataFromServerWithSuccess:^(NSArray *categories) {
        
        if (self.seasons.count) {
            [self.seasons removeAllObjects];
        }
        
        [self.seasons addObjectsFromArray:categories];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.tableView reloadData];
        });
        
    } failure:^(NSError *error) {
        
        NSLog(@"食物分类出现错误:%@", error);
        
    } withParams:@{@"kind":self.category}];
}

#pragma mark - TableView delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.seasons.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GJFoodGroupCategory * model = self.seasons[indexPath.row];
    
    GJFoodSeasonCell * cell = [GJFoodSeasonCell cellWithTableView:tableView];
    
    cell.categoryModel = model;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GJFoodGroupCategory * model = self.seasons[indexPath.row];
    
    GJFoodsDetailController * foodsVC = [[GJFoodsDetailController alloc] init];
    
    foodsVC.title = model.name;
    foodsVC.model = model;
    foodsVC.kind = self.category;
    
    [self.navigationController pushViewController:foodsVC animated:YES];
}

#pragma mark - getter
- (UITableView *)tableView {
    
    if (!_tableView) {
        _tableView = [[UITableView alloc] init];
        _tableView.frame = self.view.bounds;
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.bounces = NO;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [[UIView alloc] init];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}

- (NSMutableArray *)seasons {
    
    if (!_seasons) {
        _seasons = [NSMutableArray array];
    }
    return _seasons;
}

@end
