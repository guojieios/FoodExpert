//
//  GJFoodCategotySeasonController.h
//  FoodExpert
//
//  Created by qf on 16/04/20.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJBaseViewController.h"

@interface GJFoodCategotySeasonController : GJBaseViewController

@property (nonatomic, copy) NSString * category;



@end
