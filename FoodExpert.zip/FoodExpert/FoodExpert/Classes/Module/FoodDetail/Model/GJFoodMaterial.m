//
//  GJFoodMaterial.m
//  FoodExpert
//
//  Created by ljunb on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodMaterial.h"
#import "GJCookStep.h"
#import "GJMaterialCondiment.h"

@implementation GJFoodMaterial

#pragma mark - 数组中的模型类型
+ (NSDictionary *)objectClassInArray {
    return @{@"condiments":[GJMaterialCondiment class], @"steps":[GJCookStep class]};
}

#pragma mark - 替代的key
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"food_id":@"id"};
}

@end
