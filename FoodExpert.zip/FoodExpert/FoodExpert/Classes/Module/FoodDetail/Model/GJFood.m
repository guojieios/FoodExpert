//
//  GJFood.m
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFood.h"
#import "GJFoodUnits.h"


@implementation GJFood

+ (NSDictionary *)objectClassInArray {
    return @{@"units":[GJFoodUnits class]};
}

+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"food_id":@"id"};
}

@end
