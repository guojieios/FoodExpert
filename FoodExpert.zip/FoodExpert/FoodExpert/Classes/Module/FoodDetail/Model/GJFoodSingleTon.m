//
//  GJFoodSingleTon.m
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodSingleTon.h"

@implementation GJFoodSingleTon

static GJFoodSingleTon * food = nil;
+ (instancetype)sharedFood {
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        food = [[GJFoodSingleTon alloc] init];
    });
    return food;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    
    if (food == nil) {
        food = [super allocWithZone:zone];
    }
    return food;
}

@end
