//
//  GJFoodSingleTon.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GJFoodSingleTon : NSObject

@property (nonatomic, copy) NSString * foodCode;

/**
 *  食物单例，用来共享食物编码
 *
 *  @return 返回食物单例
 */
+ (instancetype)sharedFood;

@end
