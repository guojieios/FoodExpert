//
//  GJFoodLights.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//  食物备注
/**
 *  "lights": {
 "calory": "低热量",
 "protein": "",
 "carbohydrate": "",
 "fat": "低脂肪",
 "fiber_dietary": ""
 }
 */

#import <Foundation/Foundation.h>

@interface GJFoodLights : NSObject

@property (nonatomic, copy) NSString * calory;
@property (nonatomic, copy) NSString * protein;
@property (nonatomic, copy) NSString * fat;
@property (nonatomic, copy) NSString * carbohydrate;
@property (nonatomic, copy) NSString * fiber_dietary;

@end
