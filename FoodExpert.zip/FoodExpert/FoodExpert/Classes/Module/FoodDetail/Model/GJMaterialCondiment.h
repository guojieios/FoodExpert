//
//  GJMaterialCondiments.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//  原料
/**
 *   "condiments": [
 {
 "name": "水磨糯米粉",
 "amount": "100克"
 },
 */
#import <Foundation/Foundation.h>

@interface GJMaterialCondiment : NSObject

@property (nonatomic, copy) NSString * name;

@property (nonatomic, copy) NSString * amount;

@end
