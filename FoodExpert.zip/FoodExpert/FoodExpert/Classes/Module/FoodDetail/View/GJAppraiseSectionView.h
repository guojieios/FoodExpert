//
//  GJAppraiseSectionView.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJAppraiseSectionView : UITableViewHeaderFooterView

/**
 *  返回自定制的食物评价视图
 *
 *  @param tableView 显示的表格视图
 */
+ (instancetype)sectionViewWithTableView:(UITableView *)tableView;

/**
 *  设置section标题
 */
@property (nonatomic, assign) KFoodSectionType sectionType;

- (void)configTitleWithTitles:(NSArray *)titles;

@end
