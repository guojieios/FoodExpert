//
//  GJMoreSectionView.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJMoreSectionView : UITableViewHeaderFooterView

/**
 *  返回自定制的查看更多营养元素视图
 *
 *  @param tableView 显示的表格视图
 */
+ (instancetype)sectionViewWithTableView:(UITableView *)tableView;

@property (nonatomic, copy) void(^ShowMoreIngredientInfoAction)();

@end
