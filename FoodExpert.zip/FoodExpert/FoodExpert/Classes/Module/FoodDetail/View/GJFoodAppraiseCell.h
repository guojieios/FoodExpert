//
//  GJFoodAppraiseCell.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//  食物评价

#import <UIKit/UIKit.h>

@class GJFood;

@interface GJFoodAppraiseCell : UITableViewCell

/**
 *  食物模型
 */
@property (nonatomic, strong) GJFood * model;

/**
 *  食物原料与做法block
 */
@property (nonatomic, copy) void(^FoodMaterialAction)();

/**
 *  工厂方法
 *
 *  @param tableView 需要显示的TableView
 *
 *  @return 返回自定义的食物评价cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;

@end
