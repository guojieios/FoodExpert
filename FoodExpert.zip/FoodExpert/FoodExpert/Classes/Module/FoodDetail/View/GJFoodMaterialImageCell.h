//
//  GJFoodMaterialImageCell.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJFoodMaterialImageCell : UITableViewCell

/**
 *  快速创建食物图片cell的工程方法
 *
 *  @param tableView 装载的tableView
 *
 *  @return 自定义的食物图片cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;

@property (nonatomic, copy) NSString * imageUrl;

@end
