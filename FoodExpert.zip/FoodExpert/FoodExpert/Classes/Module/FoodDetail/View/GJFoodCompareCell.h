//
//  GJFoodCompareCell.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJFood;

@interface GJFoodCompareCell : UITableViewCell

/**
 *  创建食物对比cell
 *
 *  @param tableView 装载的TableView
 *
 *  @return 食物对比cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;

/**
 *  食物对比模型
 */
@property (nonatomic, strong) GJFood * model;


@end
