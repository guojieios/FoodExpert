//
//  GJMoreSectionView.m
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJMoreSectionView.h"

@interface GJMoreSectionView ()

@property (nonatomic, strong) UILabel * content;

@end

@implementation GJMoreSectionView

+ (instancetype)sectionViewWithTableView:(UITableView *)tableView {
    
    static NSString * ID = @"more_section_view";
    
    GJMoreSectionView * sectionView = [tableView dequeueReusableHeaderFooterViewWithIdentifier:ID];
    if (!sectionView) {
        sectionView = [[GJMoreSectionView alloc] initWithReuseIdentifier:ID];
    }
    return sectionView;
}

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        [self addSubviews];
    }
    return self;
}

#pragma mark - 适配子控件
- (void)addSubviews {
    
    [self.content mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.centerY.equalTo(self.contentView.mas_centerY);
    }];
    
    self.content.text = @"查看更多信息";
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [self.contentView addGestureRecognizer:tap];
}

#pragma mark - 单击手势
- (void)tapAction {
    
    // 回调查看更多营养信息
    if (self.ShowMoreIngredientInfoAction) {
        self.ShowMoreIngredientInfoAction();
    }
}

#pragma mark - getter
- (UILabel *)content {
    
    if (!_content) {
        _content = [[UILabel alloc] init];
        _content.font = [UIFont systemFontOfSize:13];
        _content.textColor = [UIColor darkGrayColor];
        [self.contentView addSubview:_content];
    }
    return _content;
}

@end
