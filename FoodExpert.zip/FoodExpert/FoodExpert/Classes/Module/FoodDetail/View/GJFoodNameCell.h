//
//  GJFoodNameCell.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJFood;

@interface GJFoodNameCell : UITableViewCell

/**
 *  食物模型
 */
@property (nonatomic, strong) GJFood * model;


/**
 *  快速创建食物详情名称cell
 *
 *  @param tableView 外部传入的tableView
 *
 *  @return 返回自定义的食物名称cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;



@end
