//
//  GJFoodCaloryCell.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GJFoodUnits;

@interface GJFoodCaloryCell : UITableViewCell

/**
 *  工厂方法
 *
 *  @param tableView 需要显示的TableView
 *
 *  @return 返回自定义的食物热量cell
 */
+ (instancetype)cellWithTableView:(UITableView *)tableView;

/**
 *  食物热量模型
 */
@property (nonatomic, strong) GJFoodUnits * model;



@end
