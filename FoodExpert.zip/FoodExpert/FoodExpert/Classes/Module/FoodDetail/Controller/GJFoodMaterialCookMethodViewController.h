//
//  GJFoodMaterialViewController.h
//  FoodExpert
//
//  Created by qf on 16/04/04.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GJBaseViewController.h"

@interface GJFoodMaterialCookMethodViewController : GJBaseViewController

@end
