//
//  GJClearHistoryCell.h
//  FoodExpert
//
//  Created by qf on 16/04/10.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJClearHistoryCell : UITableViewCell

+ (instancetype)cellWithTableView:(UITableView *)tableView;

@property (nonatomic, copy) void(^ClearHistoryAction)();

@end
