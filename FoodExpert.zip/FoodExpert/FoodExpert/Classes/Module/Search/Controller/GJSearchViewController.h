//
//  GJSearchViewController.h
//  FoodExpert
//
//  Created by qf on 16/04/10.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJBaseViewController.h"

@interface GJSearchViewController : GJBaseViewController

@end
