//
//  GJHTTPTool.h
//  FoodExpert
//
//  Created by qf on 16/04/24.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GJHTTPTool : NSObject

/**
 *  请求网络数据方法
 */
+ (void)getDataWithURL:(NSString *)url
                params:(NSDictionary *)params
               success:(void(^)(id response))success
               failure:(void(^)(NSError * error))failure;

@end
