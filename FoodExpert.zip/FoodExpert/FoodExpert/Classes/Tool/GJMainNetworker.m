
//
//  GJMainNetworker.h
//  FoodExpert
//
//  Created by qf on 16/04/25.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJMainNetworker.h"
#import "GJHTTPTool.h"

#import "GJMainFood.h"
#import "GJMainTopic.h"
#import "GJTopicPage.h"

@implementation GJMainNetworker

#pragma mark - 请求首页广告栏数据
+ (void)getBannerDataFromServerWithSuccess:(void (^)(NSArray *models))success failure:(void (^)(NSError *error))failure {
    
    [GJHTTPTool getDataWithURL:KMainBanner_URL params:nil success:^(id response) {
        
        if (response) {
            
            NSMutableArray * models = [NSMutableArray array];
            
            [models addObject:[GJMainFood objectWithKeyValues:response[@"banner"]]];
            
            [models addObjectsFromArray:[GJMainFood objectArrayWithKeyValuesArray:response[@"others"]]];
            
            // 回传模型数组
            if (success) {
                success(models);
            }
            
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}

#pragma mark - 请求首页专题数据
+ (void)getTopicDataFromServerWithSuccess:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure {
    
    [GJHTTPTool getDataWithURL:KMainTopic_URL params:nil success:^(id response) {
        
        if (response) {
            
            NSMutableArray * topics = [NSMutableArray array];
            
            [topics addObjectsFromArray:[GJMainTopic objectArrayWithKeyValuesArray:response[@"topics"]]];
            
            // 回传模型数组
            if (success) {
                success(topics);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}

#pragma mark - 请求专题详情页数据
+ (void)getTopicPageDataFromServerWithSuccess:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure withTopicId:(NSString *)topicId {
    
    NSString * url = [NSString stringWithFormat:@"%@/%@", KMainTopic_URL, topicId];
    
    [GJHTTPTool getDataWithURL:url params:nil success:^(id response) {
        
        if (response) {
            
            NSMutableArray * pages = [NSMutableArray array];
            
            [pages addObjectsFromArray:[GJTopicPage objectArrayWithKeyValuesArray:response[@"topic"][@"pages"]]];
            
            if (success) {
                success(pages);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}

#pragma mark - 请求关键词数据
+ (void)getKeywordsDataFromServerWithSuccess:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure {
    
    [GJHTTPTool getDataWithURL:KKeywords_URL params:nil success:^(id response) {
        
        if (response) {
            
            if (success) {
                success(response[@"keywords"]);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}
@end
