//
//  GJDBHelper.h
//  FoodExpert
//
//  Created by qf on 16/04/24.
//  Copyright © 2016年 qf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "GJFood.h"

@interface GJDBTool : NSObject

/** 单例*/
+ (instancetype)sharedDatabase;

/** 是否存在*/
- (BOOL)isExistsFood:(NSString *)foodCode;

/** 缓存数据*/
- (BOOL)saveFood:(GJFood *)model;

/** 删除数据*/
- (BOOL)removeFood:(GJFood *)model;

/** 读取所有数据*/
- (NSArray *)getAllFoods;

/** 删除所有数据*/
- (BOOL)removeAllFoods;

@end
