//
//  GJFoodNetworker.m
//  FoodExpert
//
//  Created by qf on 16/04/24.
//  Copyright © 2016年 qf. All rights reserved.
//

#import "GJFoodNetworker.h"
#import "GJHTTPTool.h"

#import "GJFood.h"
#import "GJFoodMaterial.h"
#import "GJFoodGroupCategory.h"

@implementation GJFoodNetworker

+ (void)getFoodDataFromServerWithSuccess:(void (^)(id model))success
                                 failure:(void (^)(NSError *))failure
                            withFoodCode:(NSString *)code
                                foodType:(KFoodDataType)type {
    
    NSString * url;
    if (type == KFoodDataDetailType) {
        url = [NSString stringWithFormat:KFood_URL, code];
    } else {
        url = [NSString stringWithFormat:KFoodMaterialCook_URL, code];
    }
    
    [GJHTTPTool getDataWithURL:url params:nil success:^(id response) {
        
        if (response) {
            
            id foodModel;
            if (type == KFoodDataDetailType) {
                foodModel = [GJFood objectWithKeyValues:response];
            } else {
                foodModel = [GJFoodMaterial objectWithKeyValues:response];
            }
            
            if (success) {
                success(foodModel);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
    
}

+ (void)getFoodCategoryDataFromServerWithSuccess:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure withParams:(NSDictionary *)params {
    
    [GJHTTPTool getDataWithURL:KFoodCategory_URL params:params success:^(id response) {
        
        if (response) {
            
            NSArray * categories = [GJFoodGroupCategory objectArrayWithKeyValuesArray:response[@"categories"]];
            
            if (success) {
                success(categories);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}

+ (void)getFoodsDataFromServerWithSuccess:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure withParams:(NSDictionary *)params {
    
    [GJHTTPTool getDataWithURL:KFoods_URL params:params success:^(id response) {
        
        if (response) {
            
            NSArray * foods = [GJFood objectArrayWithKeyValuesArray:response[@"foods"]];
            
            if (success) {
                success(foods);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}

+ (void)searchFoodsDataFromServerWithSuccess:(void (^)(NSArray *))success failure:(void (^)(NSError *))failure withParams:(NSDictionary *)params {
    
    [GJHTTPTool getDataWithURL:KSearch_URL params:params success:^(id response) {
        
        if (response) {
            
            NSArray * foods = [GJFood objectArrayWithKeyValuesArray:response[@"foods"]];
            
            if (success) {
                success(foods);
            }
        }
        
    } failure:^(NSError *error) {
        
        if (failure) {
            failure(error);
        }
    }];
}

@end
