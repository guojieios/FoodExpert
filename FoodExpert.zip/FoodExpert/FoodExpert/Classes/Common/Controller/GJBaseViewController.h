//
//  GJBaseViewController.h
//  FoodExpert
//
//  Created by qf on 15/11/17.
//  Copyright © 2015年 qf. All rights reserved.
//  

#import <UIKit/UIKit.h>

@interface GJBaseViewController : UIViewController

- (void)setupNavigationBar;

- (void)backAction;

@end
